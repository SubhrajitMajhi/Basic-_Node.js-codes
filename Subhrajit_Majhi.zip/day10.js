// Store text
let text = "Subhra";

// Convert to uppercase
let upperText = text.toUpperCase();

// Print result
console.log(text, upperText);