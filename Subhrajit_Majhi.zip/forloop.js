for(i=1; i<=10; i++)
{
    if (i===5)
    console.log(i)
}

//
for(i=1; i<=10; i++)
{
    if (i===6)
     { continue;}
    console.log(i)
    
}
