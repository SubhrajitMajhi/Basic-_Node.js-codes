let pass=1234
let user="8542"

