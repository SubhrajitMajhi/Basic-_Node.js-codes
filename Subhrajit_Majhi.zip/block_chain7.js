let a=4
{
    console.log("found in outer")
    {
        console.log("found in inner")
        {
            console.log("found in inner core")
        }
    }
}
