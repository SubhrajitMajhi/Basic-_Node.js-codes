let a= 10
let b=32
a= a+b
b= a-b
a= a-b

console.log("a:" +a, "b:" +b)

