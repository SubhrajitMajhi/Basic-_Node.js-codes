let a=5
fact=1
for (a=1; a<=5; a++)
{   
    fact *= a
    console.log("factorial of",a, "is", fact )
}
