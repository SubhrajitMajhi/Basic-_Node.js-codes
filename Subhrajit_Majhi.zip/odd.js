
for (let i=0; i<=100; i++)
{
    if (i%2!=0)
        console.log(i) 
}

//another

let a=32
{
    var b = 54
   let c= 34
}
console.log(a)
console.log(b)