function name1(myname)
{
    console.log("Hello ", myname, "Good Morning")
}
name1("SubhrajitMajhi")

//

function checkoddeven(num)
{
    if(num%2===0)
        console.log("even")
    else
        console.log("odd")
}
checkoddeven(97)

 