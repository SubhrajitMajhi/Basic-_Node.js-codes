console.log("Hello")
console.log(typeof"hello" +"hello") 


let info = {
    name:"Subhra",
    age:21,
    college:"NIT" 
}
console.log(info)

const myage=21
console.log(myage)


let address="Bishnupur"
console.log(address)


let x="savi"
let y="savi"
let z="subhra"

if(x==y)
console.log(" x and y are same")

else
    console.log("not valid")

if(x==z)
    console.log("x and z are same")

else
    console.log("x and z aren't same")

let xy = 0
for (i=1; i<=15; i++)
{
    xy+=i
}
console.log("sum is " + xy)